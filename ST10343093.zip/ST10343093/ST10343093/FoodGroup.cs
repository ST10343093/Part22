﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10343093
{
    //namespace begin
    //enum to hold the 6 food groups
    public enum FoodGroup
        {
            CARBOHYDRATE,
            PROTEIN,
            FAT,
            FRUIT,
            VEGETABLE,
            DAIRY

        }
    }


