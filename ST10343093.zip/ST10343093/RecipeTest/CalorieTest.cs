using ST10343093;
using System.Security.Cryptography;
using System.Xml.Linq;
namespace RecipeTest

{
    [TestClass]
    public class CalorieTest
    {
        [TestMethod]
        public void TestCalorieCalculation()
        {
            List<Ingredient> ingredients = new List<Ingredient>(); // Switched to List<Ingredient> from Ingredient[]
            // Arrange: Set-up the objects, Inputs, expected outcome
            ingredients.Add(new Ingredient { Name = "Milk", Quantity = 2, Unit = "Cups", calories = 300, FoodGroup = FoodGroup.FAT});
            ingredients.Add(new Ingredient { Name = "Milk", Quantity = 2, Unit = "Cups", calories = 300, FoodGroup = FoodGroup.FAT });
            ingredients.Add(new Ingredient { Name = "Milk", Quantity = 2, Unit = "Cups", calories = 300, FoodGroup = FoodGroup.FAT });
            Recipe recipe = new Recipe();
            recipe.setIngredients(ingredients);
            double totalCalories = recipe.calculateTotalCalories();

            Assert.AreEqual(900, totalCalories);
        }

        [TestMethod]
        public void TestCalorieAllert()
        {
            List<Ingredient> ingredients = new List<Ingredient>(); // Switched to List<Ingredient> from Ingredient[]
            ingredients.Add(new Ingredient { Name = "Milk", Quantity = 2, Unit = "Cups", calories = 300, FoodGroup = FoodGroup.FAT });
            ingredients.Add(new Ingredient { Name = "Milk", Quantity = 2, Unit = "Cups", calories = 300, FoodGroup = FoodGroup.FAT });
            ingredients.Add(new Ingredient { Name = "Milk", Quantity = 2, Unit = "Cups", calories = 300, FoodGroup = FoodGroup.FAT });


            Recipe recipe = new Recipe();
            recipe.setIngredients(ingredients);

            double totalCalories = recipe.calculateTotalCalories();
            Assert.AreEqual(900, totalCalories);
            recipe.displayCalories(1);
            // will display calories over 300 warning


        }

        [TestMethod]
        public void TestLowCalorieMeal()
        {
            Recipe recipe = new Recipe();
            recipe.displayCalories(350);
            string result = recipe.Message();

            Assert.AreEqual("Low Calorie Meal", result);
            

        }
        [TestMethod]
        public void TestAverageCalorieMeal()
        {
            Recipe recipe = new Recipe();
            recipe.displayCalories(600);
            string result = recipe.Message();

            Assert.AreEqual("Average Calorie Meal", result);

          
        

        }

        [TestMethod]
        public void TestHighCalorieMeal()
        {
            Recipe recipe = new Recipe();
            recipe.displayCalories(1000);
            string result = recipe.Message();

            Assert.AreEqual("High Calorie Meal", result);
           
        }

        [TestMethod]
        public void TestSnackCalorie()
        {
            Recipe recipe = new Recipe();
            recipe.displayCalories(150);
            string result = recipe.Message();

            Assert.AreEqual("Snack", result);
            // will display that calorie amount is a snack

        }



    }
}